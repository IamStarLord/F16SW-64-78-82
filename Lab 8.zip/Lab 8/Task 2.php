<!DOCTYPE html>
<html>
    <head>
        <title>Display Strings</title>
    </head>
    <body>
        <h1>This documents displays some strings</h1>
        <p><?php echo "Tomorrow I'll learn something new" ?></p>
        <p><?php echo "This is a bad command: del c:\\*.*\\$" ?></p>
    </body>
</html>