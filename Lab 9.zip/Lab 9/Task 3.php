<!DOCTYPE html>
<html>
    <head>
        <title>Capitals</title>
    </head>
    <body>
        <?php 
            $arr = array(
                "Italy" => "Rome",
                "Luxembourg" => "Luxembourg",
                "Belgium" => "Brussels",
                "Denmark" => "Copenhagen",
                "Finaland" => "Helsinki",
                "France" => "Paris",
                "Slovakia" => "Bratislava",
                "Slovenia" => "Ljublijana",
                "Germany" => "Berlin",
                "Greece" => "Athens",
                "Ireland" => "Dublin",
                "Netherlands" => "Amsterdam",
                "Portugal" => "Lisbon", 
                "Spain" => "Madrid", 
                "Sweden" => "Stockholm",
                "United Kingdom" => "London", 
                "Cyprus" => "Nicosia",
                "Lithuania" => "Vilnius",
                "Czech Republic" => "Prague",
                "Estonia" => "Tallin", 
                "Hungary" => "Budapest",
                "Latvia" => "Riga",
                "Malta" => "Valetta",
                "Austria" => "Vienna", 
                "Poland" => "Warsaw"
            );

            // sort the list by the capital of the country 
            asort($arr);
            foreach ($arr as $country => $capital) {
                echo "<p>The capital of ".$country." is ".$capital."</p>";
            }
        ?>
    </body>
</html>